import os
import xml.etree.ElementTree
from xml.etree.ElementTree import ElementTree
import re
from decimal import Decimal
def modify_utf():
	with open('summary.xml', 'r') as content_file:
		content = content_file.read()
		#print("read done")
	#content[35]=""
	if("utf-16" in content):
		#print "found"
		content=content[0:34]+"8"+content[36:]
		f = open("summary.xml", "w")
		f.write(content)
		f.close()
def modifysummary(Tizen_dll_version,Xamarin_dll_version,commitid):
	modify_utf()
	string=""
	total_provided_api=0
	total_covered_api=0
	# Tizen_dll_version="4.0.0"
	# Xamarin_dll_version="5.0.1"
	e1=xml.etree.ElementTree.parse("summary.xml").getroot()
	for child in e1:
		#print(child.tag,child.attrib['name'])
		string+= "<module name=\""+child.attrib['name']+"\">\n"
		provided_api=int(child[0].text)+int(child[1].text)+int(child[2].text)+int(child[3].text)
		covered_api=provided_api-int(child[4].text)-int(child[5].text)-int(child[6].text)-int(child[7].text)
		coverage=round(float(covered_api)/provided_api,4)*100
		coverage_int=int(coverage)
		coverage_float=int(round(coverage-coverage_int,4)*100)
		total_provided_api+=provided_api
		total_covered_api+=covered_api
		string+="<provided>"+str(provided_api)+"</provided>\n"
		string+="<covered>"+str(covered_api)+"</covered>\n"
		string+="<coverage_int>"+str(coverage_int)+"</coverage_int>\n"
		string+="<coverage_float>"+str(coverage_float)+"</coverage_float>\n"
		string+="</module>\n"
		#print("-----in a module---")
		#print(coverage,provided_api,covered_api)
	#print(total_covered_api,total_provided_api)
	total_coverage=round(float(total_covered_api)/total_provided_api,4)*100
	string+="<Total>\n"
	string+="<provided>"+str(total_provided_api)+"</provided>\n"
	string+="<covered>"+str(total_covered_api)+"</covered>\n"
	string+="<coverage>"+str(total_coverage)+"</coverage>\n"
	string+="</Total>\n"
	string1="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
	string1+="<?xml-stylesheet type = \"text/xsl\" href=\"style/api_coverage.xsl\"?>\n"
	string1+="<Report>\n"
	string1+="<tizen_dll>"+str(Tizen_dll_version)+"</tizen_dll>\n"
	string1+="<xamarin_dll>"+str(Xamarin_dll_version)+"</xamarin_dll>\n"
	string1+="<commit>"+str(commitid)+"</commit>"
	string1+="<provided_api>"+str(total_provided_api)+"</provided_api>\n"
	string1+="<covered_api>"+str(total_covered_api)+"</covered_api>\n"
	string1+="<coverage>"+str(total_coverage)+"</coverage>\n"
	string1+=string
	string1+="</Report>"
	f = open("summary.xml", "w")
	f.write(string1)
	f.close()
