import os
import subprocess

def get_api_tools():
	dictionary={}
	dictionary['current_dir']=os.getcwd()
	text=""
	
	if(os.path.exists(dictionary['current_dir']+"/tools/ApiCoverageTool")):
		os.chdir(dictionary['current_dir']+"/tools/ApiCoverageTool")
		  
		p=subprocess.Popen("git reset --hard", shell=True, stdout=subprocess.PIPE)
		text = p.stdout.read()
		
		p=subprocess.Popen("git pull", shell=True, stdout=subprocess.PIPE)  # need to check for up to date
		text += p.stdout.read()
		os.chdir(dictionary['current_dir'])
	else:
		os.chdir(dictionary['current_dir']+"/tools")
		
		p=subprocess.Popen("git clone git@github.sec.samsung.net:RS8-DotNetTctTools/ApiCoverageTool.git", shell=True, stdout=subprocess.PIPE)
		text += p.stdout.read()
		os.chdir(dictionary['current_dir'])
	os.chdir(dictionary['current_dir']+"/report")
	print text
	myfile = open("log.txt", "w")  
	myfile.write(text)
	myfile.close
	os.chdir(dictionary['current_dir'])

def get_abi_tools():
	dictionary={}
	dictionary['current_dir']=os.getcwd()
	text=""
	if(os.path.exists(dictionary['current_dir']+"/tools/AbiTool")):
		os.chdir(dictionary['current_dir']+"/tools/AbiTool")  
		p=subprocess.Popen("git reset --hard", shell=True, stdout=subprocess.PIPE)
		text += p.stdout.read()		
		p=subprocess.Popen("git pull", shell=True, stdout=subprocess.PIPE)  # need to check for up to date# need to check for up to date
		text += p.stdout.read()
		os.chdir(dictionary['current_dir'])
	else:
		os.chdir(dictionary['current_dir']+"/tools")

		p=subprocess.Popen("git clone git@github.sec.samsung.net:RS8-DotNetTctTools/AbiTool.git", shell=True, stdout=subprocess.PIPE)
		text += p.stdout.read()
		os.chdir(dictionary['current_dir'])
	os.chdir(dictionary['current_dir']+"/report")
	print text
	myfile = open("log.txt", "a")  
	myfile.write(text)
	myfile.close
	os.chdir(dictionary['current_dir'])
