import xml_parser
import os
import xml.etree.ElementTree
import shutil
import subprocess
import re

def printMissingDllLogs(current_dir, version, api_missing_dll_dictionary):
	f = open(current_dir+"/report/Missing_DLL_Api_Tizen"+version+".txt", "w+")
	f.write("Missing DLL list in API Coverage Tizen"+version+"\n")

	for key, value in api_missing_dll_dictionary.iteritems():
		f.write(key+":->"+value+"\n")

	f.close()

def create_csv(version):
	current_dir=os.getcwd()
	api5=os.getcwd()+"/tools/ApiCoverageTool/scripts/tizen5_coverage.xml" #tizen5_coverage.xml
	api4=os.getcwd()+"/tools/ApiCoverageTool/scripts/tizen4_coverage.xml"
	exe_dir=os.getcwd()+"/tools/ApiCoverageTool/latestRelease/TizenCSCoverage.exe"
	if(os.path.exists(current_dir+"/report/api")):
		shutil.rmtree(current_dir+"/report/api")

	os.chdir(current_dir+"/report")
	os.makedirs("api")
	os.chdir(current_dir)
	if(re.match(version,"all")):

		e1=xml.etree.ElementTree.parse(api5).getroot()
		e2=xml.etree.ElementTree.parse(api4).getroot()
		api4_xml_path=os.getcwd()+"/tools/ApiCoverageTool/scripts/TAM_Tizen_API4.xml"
		api5_xml_path=os.getcwd()+"/tools/ApiCoverageTool/scripts/TAM_Tizen_API5.xml"
		api5_missing_dll_dictionary=xml_parser.modify_xml("5",e1)
		api4_missing_dll_dictionary=xml_parser.modify_xml("4",e2)
		os.chdir(current_dir+"/report/api")
		command=["mono "+exe_dir+" -f "+api4_xml_path+" -r c"]
		p=subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
		text = p.stdout.read()
		if(os.path.isdir(os.getcwd()+"/api_coverage_report_api4")):
			shutil.rmtree(os.getcwd()+"/api_coverage_report_api4")
		os.rename("Report","api_coverage_report_api4")
		command1=["mono "+exe_dir+" -f "+api5_xml_path+" -r c"]
		p=subprocess.Popen(command1, shell=True, stdout=subprocess.PIPE)
		text += p.stdout.read()
		if(os.path.isdir(os.getcwd()+"/api_coverage_report_api5")):
			shutil.rmtree(os.getcwd()+"/api_coverage_report_api5")
		os.rename("Report","api_coverage_report_api5")

		#Log for Missing Dll 
		printMissingDllLogs(current_dir, "5", api5_missing_dll_dictionary)
		printMissingDllLogs(current_dir, "4", api4_missing_dll_dictionary)

	else:
		if(re.match(version,"4")):
			e=xml.etree.ElementTree.parse(api4).getroot()
		else:
			e=xml.etree.ElementTree.parse(api5).getroot()
		xml_path=os.getcwd()+"/tools/ApiCoverageTool/scripts/TAM_Tizen_API"+version+".xml"
		missing_dll_dictionary=xml_parser.modify_xml(version,e)

		os.chdir(current_dir+"/report/api")
		command=["mono "+exe_dir+" -f "+xml_path+" -r c"]
		p=subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
		text = p.stdout.read()
		if(os.path.isdir(os.getcwd()+"/api_coverage_report_api"+version)):
			shutil.rmtree(os.getcwd()+"/api_coverage_report_api"+version)
		os.rename("Report","api_coverage_report_api"+version)

		#Log for Missing Dll
		printMissingDllLogs(current_dir, version, missing_dll_dictionary) 
	
	os.chdir(current_dir+"/report")
	myfile = open("log.txt", "a")  
	myfile.write(text)
	myfile.close
	#print text
	
	os.chdir(current_dir)
