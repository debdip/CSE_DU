import os
import subprocess
import shutil
import zipfile
import modify_summary_api
global blankCount, headerCheck, previousDll, previousNamespace, previousClass, leftOffDll, leftOffNamespace,leftOffClass, leftOff, previousThings, tagName, tableHeader
import xml.etree.ElementTree
from xml.etree.ElementTree import ElementTree
previousDll =""
previousNamespace = ""
previousClass = ""

leftOffDll = ""
leftOffNamespace = ""
leftOffClass = ""

leftOff = ["" for x in range(3)]
previousThings = ["" for x in range(3)]
tagName = ["Dll", "NamespaceName", "class"]

tableHeader = []

def checkThings(lookupString, type, f):
	if(lookupString != previousThings[type]):
		# print(lookupString+"\t"+previousThings[type])
		for i in range(2,type-1,-1):
			if(len(leftOff[i])>0):
				writeToFile(f, leftOff[i])
				leftOff[i] = ""

		previousThings[type] = lookupString
		writeToFile(f, "<"+tagName[type]+" name=\""+lookupString+"\">")
		leftOff[type] = "</"+tagName[type]+">"

def testForSpecialChar(valueText):
	valueText = ("&lt;").join(valueText.split("<"))
	valueText = ("&gt;").join(valueText.split(">"))
	valueText = ("&amp;").join(valueText.split("&"))
	valueText = ("&quot;").join(valueText.split("\""))
	valueText = ("&apos;").join(valueText.split("'"))
	return valueText

def writeToFile(f, xmlText):
	# print("Now write:  "+xmlText)
	f.write(xmlText+"\n")
	return f


def getTableData(rawLine):
	allData = []
	tmp = ""
	rawLine = list(rawLine)
	presentStack=0
	for i in range(0,len(rawLine)):
		if rawLine[i]==",":
			if presentStack==0:
				tmp = testForSpecialChar(tmp)
				allData.append(tmp)
				tmp=""
			else:
				tmp+= rawLine[i]

		elif rawLine[i]=="\"":
			if i>0 and rawLine[i-1]==",":
				presentStack=1
			if i<len(rawLine) and rawLine[i+1]==",":
				presentStack=0

		else:
			tmp +=rawLine[i]
	tmp = testForSpecialChar(tmp)
	allData.append(tmp)
	return allData

def initializeThis():
	previousDll =""
	previousNamespace = ""
	previousClass = ""

	leftOffDll = ""
	leftOffNamespace = ""
	leftOffClass = ""
	for i in range(0,3):
		leftOff[i] = ""
		previousThings[i] = ""
	del tableHeader[:]

def getBoundedTag(boundData):
	if  len(boundData.strip()) == 0:
		return "total"
	else:
		return "Dll"

def makeXML(fileCsv):
	blankCount = 2
	headerCheck = 1

	initializeThis()
	fileName = (fileCsv.split("APICoverage"))[0]

	f = open(fileName+".xml", "w+")
	f = writeToFile(f, "<?xml version=\"1.0\" encoding=\"UTF-8\"?><?xml-stylesheet type = \"text/xsl\" href=\"./style/report_index.xsl\"?>")
	f = writeToFile(f, "<module name=\""+fileName+"\">")

	with open(fileCsv) as fin:
		for line in fin:
			line = line.strip()
			
			if blankCount==0:
				if headerCheck==0:
					tableData = getTableData(line)
					for i in range(0,3):
						checkThings(tableData[i+1], i, f)
						# os.system("pause")
					f = writeToFile(f, "<API name=\""+tableData[4]+"\">")

					f = writeToFile(f, "<no>"+tableData[0]+"</no>")

					f = writeToFile(f, "<type>"+tableData[5]+"</type>")
					f = writeToFile(f, "<TC_Name>"+tableData[6]+"</TC_Name>")
					f = writeToFile(f, "<TC_Criteria>"+tableData[7]+"</TC_Criteria>")
					f = writeToFile(f, "</API>")
				else:
					f = writeToFile(f, "<details>")
					headerCheck = 0
			else:
				if len(line)==0:
					blankCount -=1
					if blankCount==0:
						headerCheck=1
						f = writeToFile(f, "</summery>")
				else:
					if headerCheck==1:
						f = writeToFile(f, "<summery>")
						headerCheck = 0

						tableData = getTableData(line)
						for i in range(2,len(tableData)):
							tableHeader.append(("_").join(tableData[i].split(" ")))
						# print(tableHeader)
					else:
						tableData = getTableData(line)

						boundTag = getBoundedTag(tableData[0])						


						f = writeToFile(f, "<"+boundTag+" name=\""+tableData[1]+"\">")
						f = writeToFile(f, "<no>"+tableData[0]+"</no>")
						for i in range(0,len(tableHeader)):
							f = writeToFile(f, "<"+tableHeader[i]+">"+tableData[i+2]+"</"+tableHeader[i]+">")
						f = writeToFile(f, "</"+boundTag+">")

	for i in range(2,-1,-1):
		if(len(leftOff[i])>0):
			f = writeToFile(f, leftOff[i])
			leftOff[i] = ""
	f = writeToFile(f, "</details>")
	f = writeToFile(f, "</module>")

	f.close()

def summeryXsl():
	srcDir = "summary.xml"
	destnDir = "tmp.xml"
	checkXML = 0
	with open(srcDir, "r") as src, open(destnDir, "w") as destn:
		for line in src:
			if len(line.strip()) == 0:
				continue
			if checkXML == 1:
				if line.strip() != ("<?xml-stylesheet type = \"text/xsl\" href=\"./style/index.xsl\"?>"):
					# print("<?xml-stylesheet type = \"text/xsl\" href=\"./style/index.xsl\"?>")
					destn.write("<?xml-stylesheet type = \"text/xsl\" href=\"./style/index.xsl\"?>\n")
				checkXML = 0
			destn.write(line)

			if line.strip() == ("<?xml version=\"1.0\" encoding=\"utf-8\"?>"):
				# print(line.strip())
				checkXML = 1
			
	os.remove(srcDir)
	os.rename(destnDir, srcDir)

def processAllCsv():
	for file in os.listdir(os.getcwd()):
		if file.endswith(".csv"):
			# fileName = (file.split("APICoverage"))[0]
			makeXML(file)

def copyStyle(pathOfStyle):
	dipto = os.getcwd()
	zip_ref = zipfile.ZipFile(dipto + "/tools/abi_style.zip", 'r')
	zip_ref.extractall(pathOfStyle)
	zip_ref.close()

def startProcessingXml(versionNumber):
	defaultDir = os.getcwd()
	#os.chdir("..")
	os.chdir(os.getcwd() + "/report/api/api_coverage_report_api"+versionNumber)
	summeryXsl()
	processAllCsv()
	os.chdir(defaultDir)

	copyStyle(os.getcwd() + "/report/api/api_coverage_report_api"+versionNumber)
	shutil.copy(defaultDir+"/tools/style/api_coverage.xsl",defaultDir+"/report/api/api_coverage_report_api"+str(versionNumber)+"/style")
	latest_dll_dir=os.listdir(defaultDir+"/dlls/latest_dlls")
	for dll in latest_dll_dir:
		if "API"+str(versionNumber) in dll:
			Tizen_new_version=dll[len("Tizen.NET.API4."):len(dll)]
		if "Xamarin.Forms.Maps" in dll:
			Xamarin_new_version=dll[len("Xamarin.Forms.Maps."):len(dll)]

	os.chdir(defaultDir+"/tcs/tizen"+versionNumber+".0/api")
	commitid=subprocess.Popen("git log --format=\"%H\" -n 1",shell=True,stdout=subprocess.PIPE)

	os.chdir(defaultDir+"/report/api/api_coverage_report_api"+versionNumber)
	
	
	modify_summary_api.modifysummary(Tizen_new_version,Xamarin_new_version,commitid.stdout.read())
	os.chdir(defaultDir)