import os
import xml.etree.ElementTree
from xml.etree.ElementTree import ElementTree
import re

def modify_xml(version,e):
	e_tree=e
	missing_dll_list={}
	current_dir=os.getcwd()

	old_dir_list=os.listdir(current_dir+"/dlls/old_dlls")
	latest_dll_list=os.listdir(current_dir+"/dlls/latest_dlls")
	for dll in old_dir_list:
		if("API"+str(version) in dll):
			old_dll_path=current_dir+"/dlls/old_dlls/"+dll+"/ref/netstandard2.0"
		if("Xamarin.Forms" in dll):
			old_xamarin_form_path=current_dir+"/dlls/old_dlls/"+dll+"/lib/netstandard1.0"

		if("Xamarin.Forms.Maps" in dll):
			old_xamarin_form_map_path=current_dir+"/dlls/old_dlls/"+dll+"/lib/netstandard1.0"
	for dll in latest_dll_list:
		if("API"+str(version) in dll):
			latest_dll_path=current_dir+"/dlls/latest_dlls/"+dll+"/ref/netstandard2.0"
		if("Xamarin.Forms" in dll):
			latest_xamarin_form_path=current_dir+"/dlls/latest_dlls/"+dll+"/lib/netstandard1.0"

		if("Xamarin.Forms.Maps" in dll):
			latest_xamarin_form_map_path=current_dir+"/dlls/latest_dlls/"+dll+"/lib/netstandard1.0"
	# e_tree = checkAll(e_tree)

	for atype in e_tree.findall('module'):
		check=0

		# os.chdir(latest_dll_path)
		needToBeRemoved = {}
		missing_dll=[]

		latestPath=""
		oldPath=""
		for temp in atype.findall('newdll'):
			dll=temp.text.split('\\')[-1]

			if(re.match("Xamarin.Forms.Core.dll",dll)):
				latestPath = latest_xamarin_form_path
				oldPath = old_xamarin_form_path
			elif (re.match("Xamarin.Forms.Maps.dll",dll)):
				latestPath = latest_xamarin_form_map_path
				oldPath = old_xamarin_form_map_path
			else:
				latestPath = latest_dll_path
				oldPath = old_dll_path

			if(os.path.isfile(latestPath+"/"+dll)  and os.path.isfile(oldPath+"/"+dll)):
				temp.text=latestPath+"/"+dll
				check=1

			else:
				missing_dll_list[atype.attrib['name']]=dll

				needToBeRemoved[dll] = 1

				atype.remove(temp)
		# os.chdir(old_dll_path)

		for temp in atype.findall('olddll'):
			dll=temp.text.split('\\')[-1]

			if(re.match("Xamarin.Forms.Core.dll",dll)):
				oldPath = old_xamarin_form_path
			elif (re.match("Xamarin.Forms.Maps.dll",dll)):
				oldPath = old_xamarin_form_map_path
			else:
				oldPath = old_dll_path

			if dll in needToBeRemoved:
				atype.remove(temp)
			else:
				temp.text = oldPath+"/"+dll
		
		if(check==0):
			e_tree.remove(atype)

	os.chdir(current_dir+"/tools/AbiTool/latestRelease")
	mydata = xml.etree.ElementTree.tostring(e_tree)

	fileName = "modules_API"+str(version)+".xml"

	if(os.path.isfile(fileName)):
		os.remove(fileName)
	myfile = open(fileName, "w")  
	myfile.write(mydata)
	myfile.close
	os.chdir(current_dir)	
	return missing_dll_list
