import os
import xml.etree.ElementTree
from xml.etree.ElementTree import ElementTree
import re

def writeToFile(f, xmlText):
	# print("Now write:  "+xmlText)
	f.write(xmlText+"\n")
	return f
def modifySummary(Tizen_dll_version_new,Tizen_dll_version_old,Xamarin_dll_version_new,Xamarin_dll_version_old):
	f = open("summary.xml", "w")
	# Tizen_dll_version_new="4.0.2"
	# Tizen_dll_version_old="4.0.1"
	# Xamarin_dll_version_new="3"
	# Xamarin_dll_version_old="4"
	files=os.listdir(os.getcwd())
	Tizen_add=0
	Tizen_remove=0
	Tizen_change=0
	Xamarin_add=0
	Xamarin_remove=0
	Xamarin_change=0
	string="\n"

	for file in files:
		if(file.endswith(".xml") and file.startswith("summary.xml")==False):
			e1=xml.etree.ElementTree.parse(file).getroot()
			string+= "<module name=\""+e1[0][0].text+"\">\n"
			string+="<add>"+e1[0][1].text+"</add>\n"
			string+="<remove>"+e1[0][2].text+"</remove>\n"
			string+="<change>"+e1[0][3].text+"</change>\n"
			string+="</module>\n"
			if(file.startswith("XamarinForms")):
				Xamarin_add+=int(e1[0][1].text)
				Xamarin_remove+=int(e1[0][2].text)
				Xamarin_change+=int(e1[0][3].text)

			else:
				Tizen_add+=int(e1[0][1].text)
				Tizen_remove+=int(e1[0][2].text)
				Tizen_change+=int(e1[0][3].text)


	string1="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
	string1+="<?xml-stylesheet type = \"text/xsl\" href=\"style/abi_style.xsl\"?>\n"
	string1+="<Report>\n"
	string1+="<listfirst name = \""+"Tizen"+"\">\n"
	string1+="<old_version>"+Tizen_dll_version_old+"</old_version>\n"
	string1+="<new_version>"+Tizen_dll_version_new+"</new_version>\n"
	string1+="<added>"+str(Tizen_add)+"</added>\n"
	string1+="<removed>"+str(Tizen_remove)+"</removed>\n"
	string1+="<changed>"+str(Tizen_change)+"</changed>\n"
	string1+= "</listfirst>\n"
	string1+="<listsecond name = \""+"xamarin"+"\">\n"
	string1+="<old_version>"+Xamarin_dll_version_old+"</old_version>\n"
	string1+="<new_version>"+Xamarin_dll_version_new+"</new_version>\n"
	string1+="<added>"+str(Xamarin_add)+"</added>\n"
	string1+="<removed>"+str(Xamarin_remove)+"</removed>\n"
	string1+="<changed>"+str(Xamarin_change)+"</changed>\n"
	string1+="</listsecond>\n"
	string1+=string
	string1+="</Report>\n"

	f.write(string1)
	# print (Tizen_add,Tizen_remove,Tizen_change)
	# print (Xamarin_add,Xamarin_remove,Xamarin_change)