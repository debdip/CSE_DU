import os
import subprocess
import re
def getConfiguration():
	dictionary={}
	dictionary['current_dir']=os.getcwd()
	infile=open(dictionary['current_dir']+"/src/config.txt")
	
	for string in infile:
		value=string.rstrip('\n').split("=")
		dictionary[value[0]]=value[1]
	return dictionary

def get_latest_tcs(tizen_version):
	dictionary = getConfiguration()
	text=""
	if(os.path.exists(dictionary['current_dir']+"/tcs/tizen"+tizen_version+".0/api/tct-suite-vs")): #
	#cur_dir=os.getcwd()
		os.chdir(dictionary['current_dir']+"/tcs/tizen"+tizen_version+".0/api")  
		p=subprocess.Popen("git reset --hard", shell=True, stdout=subprocess.PIPE)
		text = p.stdout.read()
		
		p=subprocess.Popen("git pull", shell=True, stdout=subprocess.PIPE)  # need to check for up to date
		text += p.stdout.read()
		os.chdir(dictionary['current_dir'])
	else:
		git_url="git clone ssh://"+dictionary['user_name']+"@"+dictionary['git_clone_url']
		os.chdir(dictionary['current_dir']+"/tcs/tizen"+tizen_version+".0")
		p=subprocess.Popen(git_url, shell=True, stdout=subprocess.PIPE)
		text = p.stdout.read()
		os.chdir(dictionary['current_dir']+"/tcs/tizen"+tizen_version+".0/api")
		
		if re.match("4",tizen_version):
			p=subprocess.Popen("git checkout "+dictionary['branch_name_tizen4'], shell=True, stdout=subprocess.PIPE)
		if re.match("5",tizen_version):
			p=subprocess.Popen("git checkout "+dictionary['branch_name_tizen5'], shell=True, stdout=subprocess.PIPE)
		text += p.stdout.read()
		os.chdir(dictionary['current_dir'])
	os.chdir(dictionary['current_dir']+"/report")
	#print (text)
	myfile = open("log.txt", "a")  
	myfile.write(text)
	myfile.close
	os.chdir(dictionary['current_dir'])
