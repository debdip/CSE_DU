import os
import xml.etree.ElementTree
from xml.etree.ElementTree import ElementTree
import re

def modify_xml(version,e_tree):
	missing_dll_list={}
	#os.chdir("..")
	current_dir=os.getcwd()
	path=current_dir+"/dlls/latest_dlls"
	directory=os.listdir(path)

	for string in directory:
		
		if("API"+version in string):
			dll_dir=current_dir+"/dlls/latest_dlls/"+string+"/ref/netstandard2.0"
		if(re.match("Xamarin.Forms.\d",string)):
			xamarin_form_dll_dir=current_dir+"/dlls/latest_dlls/"+string+"/lib/netstandard1.0/Xamarin.Forms.Core.dll"
		if(re.match("Xamarin.Forms.Maps.\d",string)):
			xamarin_form_maps_dll_dir=current_dir+"/dlls/latest_dlls/"+string+"/lib/netstandard1.0/Xamarin.Forms.Maps.dll"

	tc_dir=current_dir+"/tcs/tizen"+version+".0/api/tct-suite-vs"
	check=0
	
	for atype in e_tree.findall('module'):
		iterator=0
		checkIt = 0
		for eachPath in atype.findall('path'):
			os.chdir(dll_dir)

			for eachDll in eachPath.findall('dll'):
				dll=eachDll.text.split('\\')[-1]
				#t=re.search("[A-Z]",str(t))
				#dll=temp[0].text[temp[0].text.index("Tizen"):temp[0].text.index("</dll>")-1]
				if(os.path.isfile(dll)):
					dll_path=dll_dir+"/"+dll
					eachDll.text=dll_path
					checkIt = 1
					#print te.text
				else:
					if(re.match("Xamarin.Forms.Core.dll",dll)):
						eachDll.text=xamarin_form_dll_dir
						checkIt = 1
					elif(re.match("Xamarin.Forms.Maps.dll",dll)):
						eachDll.text=xamarin_form_maps_dll_dir
						checkIt = 1
					else:	
						missing_dll_list[atype.attrib['name']]=dll
						eachPath.remove(eachDll)
			
			os.chdir(tc_dir)

			for eachTest in eachPath.findall('testcase'):
				tc= eachTest.text.split('\\')[-2]
				if(os.path.exists(tc)):			
					tc_path=tc_dir+"/"+tc+"/testcase"
					eachTest.text=tc_path

				else:
					eachPath.remove(eachTest)

		if checkIt == 0:
			e_tree.remove(atype)
	#print xml.etree.ElementTree.tostring(e)
	
	mydata = xml.etree.ElementTree.tostring(e_tree)
	xml_dir=current_dir+"/tools/ApiCoverageTool/scripts"
	os.chdir(xml_dir)
	myfile = open("TAM_Tizen_API"+version+".xml", "w")  
	myfile.write(mydata)
	myfile.close
	os.chdir(current_dir)	
	return missing_dll_list
