import os
import subprocess
import shutil
from time import sleep
import re

def get_latest_dlls(packages,argv):
	dictionary={}
	dictionary['current_dir']=os.getcwd()
	latest_dll_path=dictionary['current_dir']+"/dlls/latest_dlls"
	os.chdir(dictionary['current_dir']+"/dlls/latest_dlls")
	old_dll_path=dictionary['current_dir']+"/dlls/old_dlls"
	dictionary['nuget_dir']=dictionary['current_dir']+"/tools/nuget.exe"
	dictionary1= os.listdir(os.getcwd())
	dictionary2=os.listdir(old_dll_path)
	text=""
	old_dlls_dir_name={}
	latest_dlls_dir_name={}
	for string in dictionary1:
		#print string
		if('Tizen.NET.API5' in string):
			latest_dlls_dir_name['Tizen.NET.API5']=string
		elif('Tizen.NET.API4' in string):
			latest_dlls_dir_name['Tizen.NET.API4']=string
		elif(re.match('^Xamarin.Forms.Maps.\d',string)):
			latest_dlls_dir_name['Xamarin.Forms.Maps']=string
		elif(re.match('^Xamarin.Forms.\d',string)):
			latest_dlls_dir_name['Xamarin.Forms']=string
		else:
			shutil.rmtree(latest_dll_path+"/"+string)

	for string in dictionary2:
		#print string
		if('Tizen.NET.API5' in string):
			old_dlls_dir_name['Tizen.NET.API5']=string
		if('Tizen.NET.API4' in string):
			old_dlls_dir_name['Tizen.NET.API4']=string
		if(re.match('^Xamarin.Forms.Maps.\d',string)):
			old_dlls_dir_name['Xamarin.Forms.Maps']=string
			#print "in Xamarin.Forms.Maps"
		if(re.match('^Xamarin.Forms.\d',string)):
			old_dlls_dir_name['Xamarin.Forms']=string
			#print "in Xamarin.Forms"
	#print packages
	if(re.match("all",argv) or re.match("5",argv)):
		if("Tizen.NET.API5."+packages['Tizen.NET.API5'] not in dictionary1):
			#for string in dictionary1:
			
			if 'Tizen.NET.API5' in latest_dlls_dir_name:
				shutil.rmtree(old_dll_path+"/"+old_dlls_dir_name['Tizen.NET.API5'])
				shutil.move(latest_dll_path+"/"+latest_dlls_dir_name['Tizen.NET.API5'],old_dll_path)
				#print latest_dlls_dir_name['Tizen.NET.API5']	
			p=subprocess.Popen("mono "+dictionary['nuget_dir']+" install Tizen.NET.API5 -Version "+packages['Tizen.NET.API5']+" -Source https://tizen.myget.org/F/dotnet/api/v3/index.json", shell=True, stdout=subprocess.PIPE)
			text = p.stdout.read()
	if(re.match("all",argv) or re.match("4",argv)):
		#print("in api 4")
		if("Tizen.NET.API4."+packages['Tizen.NET.API4'] not in dictionary1):
			
			#for string in dictionary1:
			if 'Tizen.NET.API4' in latest_dlls_dir_name:
				shutil.rmtree(old_dll_path+"/"+old_dlls_dir_name['Tizen.NET.API4'])
				shutil.move(latest_dll_path+"/"+latest_dlls_dir_name['Tizen.NET.API4'],old_dll_path)
				#print latest_dlls_dir_name['Tizen.NET.API4']
			p=subprocess.Popen("mono "+dictionary['nuget_dir']+" install Tizen.NET.API4 -Version  "+packages['Tizen.NET.API4']+" -Source https://tizen.myget.org/F/dotnet/api/v3/index.json", shell=True, stdout=subprocess.PIPE)
			text += p.stdout.read()
	if("Xamarin.Forms.Maps."+packages['Xamarin.Forms.Maps.Tizen'] not in dictionary1):
		#print(latest_dlls_dir_name['Tizen.NET.API4'])
		# if 'Xamarin.Forms.Maps' in latest_dlls_dir_name:
			
		# 	shutil.rmtree(old_dll_path+"/"+old_dlls_dir_name['Xamarin.Forms.Maps'])
		# 	shutil.move(latest_dll_path+"/"+latest_dlls_dir_name['Xamarin.Forms.Maps'],old_dll_path)
		# 	shutil.rmtree(old_dll_path+"/"+old_dlls_dir_name['Xamarin.Forms'])
		# 	shutil.move(latest_dll_path+"/"+latest_dlls_dir_name['Xamarin.Forms'],old_dll_path)

		# p=subprocess.Popen("mono "+dictionary['nuget_dir']+" install Xamarin.Forms.Maps.Tizen -Version 2.5.0.280555", shell=True, stdout=subprocess.PIPE)
		# text += p.stdout.read()
		dictionary3=os.listdir(dictionary['current_dir']+"/dlls/latest_dlls")
		for string in dictionary3:
		#print string
			if('Tizen.NET.API5' in string):
				latest_dlls_dir_name['Tizen.NET.API5']=string
			elif('Tizen.NET.API4' in string):
				latest_dlls_dir_name['Tizen.NET.API4']=string
			elif(re.match('^Xamarin.Forms.Maps.\d',string)):
				latest_dlls_dir_name['Xamarin.Forms.Maps']=string
			elif(re.match('^Xamarin.Forms.\d',string)):
				latest_dlls_dir_name['Xamarin.Forms']=string
			else:
				shutil.rmtree(latest_dll_path+"/"+string)
	
	os.chdir(dictionary['current_dir']+"/report")
	myfile = open("log.txt", "w")
	myfile.write(text)
	myfile.close
	os.chdir(dictionary['current_dir'])
