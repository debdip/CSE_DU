import urllib2
import ssl

def get_versions():
    version={}
    packages=["Tizen.NET.API4","Tizen.NET.API5","Xamarin.Forms.Platform.Tizen","Xamarin.Forms.Maps.Tizen"]
    #context = ssl._create_unverified_context()
    response= urllib2.urlopen('https://tizen.myget.org/gallery/dotnet')
    #print "hello"
    html = response.read()

    for pkg in packages:
        ver = html[html.index(pkg):len(html)]
        ver = ver[ver.index("/")+1:ver.index('"')]
        print(pkg+" "+ver)
        version[pkg]=ver;
    return version
