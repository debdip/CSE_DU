import os
import shutil
import xml.etree.ElementTree
from xml.etree.ElementTree import ElementTree
import re
import abi_xml_parser
import subprocess
from distutils.dir_util import copy_tree
import newsummary
def renamePathOfSummery(pathOfSummery, newFolder):
	pathOfSummery = pathOfSummery+"/XmlExport/summary.xml"
	summeryXml = xml.etree.ElementTree.parse(pathOfSummery).getroot()

	for eachModule in summeryXml.findall('module'):
		for oldPath in eachModule.findall('path'):
			oldName = oldPath.text
			oldName = newFolder.join((oldName).split("XmlExport"))
			oldPath.text = oldName

	os.remove(pathOfSummery)
	myfile = open(pathOfSummery, "w") 
	myfile.write("<?xml version=\"1.0\" encoding=\"utf-16\"?>")
	myfile.write("<?xml-stylesheet type = \"text/xsl\" href=\"./style/indexSummary.xsl\"?>") 
	myfile.write(xml.etree.ElementTree.tostring(summeryXml))
	myfile.close

def printMissingDllLogs(current_dir, version, api_missing_dll_dictionary):
	f = open(current_dir+"/report/Missing_DLL_Abi_Tizen"+version+".txt", "w+")
	f.write("Missing DLL list in Abi Measurement Tizen"+version+"\n")

	for key, value in api_missing_dll_dictionary.iteritems():
		f.write(key+":->"+value+"\n")

	f.close()

def workWithAbi(dictionary, current_dir, version):
	os.chdir(current_dir+"/report/abi")
	os.makedirs("XmlExport")
	os.chdir(current_dir+"/report/abi/XmlExport")
	os.makedirs("style")
	style_path=current_dir+"/tools/AbiTool/latestRelease/XmlExport/style"
	copy_tree(style_path,current_dir+"/report/abi/XmlExport/style")
	os.chdir(current_dir)
	path = current_dir+"/tools/AbiTool/scripts/tizen"+version+"_dlls.xml"

	exe_path=current_dir+"/tools/AbiTool/latestRelease/ABI.exe"
	xml_path=current_dir+"/tools/AbiTool/latestRelease/modules_API"+str(version)+".xml"
	xml_file=xml.etree.ElementTree.parse(path).getroot()

	missing_dlls=abi_xml_parser.modify_xml(version,xml_file)
	printMissingDllLogs(current_dir, version, missing_dlls)

	os.chdir(current_dir+"/report/abi")
	command=["mono "+exe_path+" -f "+xml_path]
		
	p=subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
	text = p.stdout.read()
	if(os.path.isdir(current_dir+"/report/abi/api_"+(version))):
		shutil.rmtree(current_dir+"/report/abi/api_"+(version))

	renamePathOfSummery(os.getcwd(), "api_"+(version))
	os.rename("XmlExport","api_"+(version))
	os.chdir(current_dir+"/report/abi/api_"+(version))
	# os.makedirs("style")
	# for string in dictionary:
	# 	shutil.copy(current_dir+"/tools/AbiTool/latestRelease/XmlExport/style/"+string,current_dir+"/report/abi/api_"+(version)+"/style")
	return text

def checkIfAnyXmlExportFolder(result_path):
	if(os.path.exists(result_path+"/XmlExport")):
		shutil.rmtree(result_path+"/XmlExport")

def deleteOld(current_dir, version):
	if(os.path.isdir(current_dir+"/report/abi/api_"+(version))):
		shutil.rmtree(current_dir+"/report/abi/api_"+(version))

def create_xml(version):
	current_dir=os.getcwd()
	dictionary=os.listdir(current_dir+"/tools/AbiTool/latestRelease/XmlExport/style")

	latest_dll_dir=os.listdir(current_dir+"/dlls/latest_dlls")
	for dll in latest_dll_dir:
		if "API"+str(version) in dll:
			Tizen_new_version=dll[len("Tizen.NET.API4."):len(dll)]
		if "Xamarin.Forms.Maps" in dll:
			Xamarin_new_version=dll[len("Xamarin.Forms.Maps."):len(dll)]

	old_dll_dir=os.listdir(current_dir+"/dlls/old_dlls")
	for dll in old_dll_dir:
		if "API"+str(version) in dll:
			Tizen_old_version=dll[len("Tizen.NET.API4."):len(dll)]
		if "Xamarin.Forms.Maps" in dll:
			Xamarin_old_version=dll[len("Xamarin.Forms.Maps."):len(dll)]

	if(re.match(version, "4") or re.match(version,"all")):
		text = workWithAbi(dictionary, current_dir, "4")
				

	if(re.match(version, "5") or re.match(version,"all")):
		text = workWithAbi(dictionary, current_dir, "5")


	os.chdir(current_dir+"/report/abi/api_"+str(version))
	newsummary.modifySummary(Tizen_new_version,Tizen_old_version,Xamarin_new_version,Xamarin_old_version)	
	shutil.copy(current_dir+"/tools/style/abi_style.xsl",current_dir+"/report/abi/api_"+str(version)+"/style")
	shutil.copy(current_dir+"/tools/style/bootsrap.min.js",current_dir+"/report/abi/api_"+str(version)+"/style")
	shutil.copy(current_dir+"/tools/style/bootstrap.css",current_dir+"/report/abi/api_"+str(version)+"/style")
	os.chdir(current_dir+"/report")
	myfile = open("log.txt", "a")  
	myfile.write(text)
	myfile.close

	os.chdir(current_dir)