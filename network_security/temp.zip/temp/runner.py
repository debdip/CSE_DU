import tc_manager
import dll_manager
import version_marger
import create_csv
import api_abi_tool_manager
import abi_process

import api_process
import os
import sys
import re
import shutil
if((len(sys.argv)==5) and(re.match("coverage",sys.argv[4]) or re.match("abi",sys.argv[4])) and re.match("-v",sys.argv[1]) and re.match("-t",sys.argv[3]) and (re.match("4",sys.argv[2]) or re.match("5",sys.argv[2]) or re.match("all",sys.argv[2]))):
	os.chdir("..")
	current_dir=os.getcwd()
	# dll_manager.get_latest_dlls(version_marger.get_versions(),sys.argv[2])
	
	
	# if re.match("all",sys.argv[2]):
	# 	tc_manager.get_latest_tcs("4")
	# 	tc_manager.get_latest_tcs("5")
	# else:
	# 	tc_manager.get_latest_tcs(sys.argv[2])
		
	if(re.match("coverage",sys.argv[4])):
		api_abi_tool_manager.get_api_tools()
		create_csv.create_csv(sys.argv[2])
		if re.match("4",sys.argv[2]) or re.match("all",sys.argv[2]):
		 	api_process.startProcessingXml("4")
		if re.match("5",sys.argv[2]) or re.match("all",sys.argv[2]):
		 	api_process.startProcessingXml("5")

	else:
		api_abi_tool_manager.get_abi_tools()
		
		if(os.path.isdir(current_dir+"/report/abi")):
			shutil.rmtree(current_dir+"/report/abi")
			os.chdir(current_dir+"/report")
			os.makedirs("abi")
			os.chdir(current_dir)

		if re.match("4",sys.argv[2]) or re.match("all",sys.argv[2]):
		 	abi_process.create_xml("4")
		if re.match("5",sys.argv[2]) or re.match("all",sys.argv[2]):
		 	abi_process.create_xml("5")
		#abi_process.create_xml(sys.argv[2])
	
else:
	print ("Please give correct arguments:")
	print ("For api coverage:-python runner.py -v 4 -t coverage")
	print ("For abi tool:-python runner.py -v 5 -t abi")
