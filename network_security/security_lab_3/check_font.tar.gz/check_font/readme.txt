in sample1 number.png each number has enough space so each of them detected
sample2 no space between numbers 
