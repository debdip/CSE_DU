#!/usr/bin/en python

print "suddipta" + "\x00"*3 + "A+"
